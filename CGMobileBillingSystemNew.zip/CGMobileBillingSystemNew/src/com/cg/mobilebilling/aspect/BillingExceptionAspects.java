package com.cg.mobilebilling.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@ControllerAdvice(basePackages={"com.cg.mobilebilling.controller"})
public class BillingExceptionAspects {
	@ExceptionHandler(BillingServicesDownException.class)
	public ResponseEntity<String> handleBillingServiceDownException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
	
	@ExceptionHandler(BillDetailsNotFoundException.class)
	public ResponseEntity<String> handleBillDetailsNotFoundException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ResponseEntity<String> handleCustomerDetailsNotFoundException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(InvalidBillMonthException.class)
	public ResponseEntity<String> handleInvalidBillMonthException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PlanDetailsNotFoundException.class)
	public ResponseEntity<String> handlePlanDetailsNotFoundException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
	@ExceptionHandler(PostpaidAccountNotFoundException.class)
	public ResponseEntity<String> handlePostpaidAccountNotFoundException(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.EXPECTATION_FAILED);
	}
}
