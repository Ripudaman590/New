package com.cg.mobilebilling.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

@RestController
public class BillingController {
	
	@Autowired
	BillingServices service;
	
	
	@RequestMapping(value="/acceptCustomerDetails",method= RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> addCustomer(@ModelAttribute Customer customer ) throws BillingServicesDownException{
		int customerID = service.acceptCustomerDetails(customer);
			return new ResponseEntity<>("Customer details added successfully. Id is "+customerID, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getCustomerDetails/{customerId}",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> getCustomerDetails(@PathVariable("customerId") int customerId) throws CustomerDetailsNotFoundException, BillingServicesDownException{
		return new ResponseEntity<Customer>( service.getCustomerDetails(customerId),HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAllCustomersJSON",headers="Accept=application/json",method= RequestMethod.GET)
	public ResponseEntity<ArrayList<Customer>> getAllCustomerDetails() throws BillingServicesDownException{
		ArrayList<Customer> customers = (ArrayList<Customer>) service.getAllCustomerDetails();
		return new ResponseEntity<>(customers,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/deleteCustomer/{customerID}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteCustomerDetails(@PathVariable("customerID") int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException	{	
		return new ResponseEntity<>("Customer with "+customerID + " deleted successfully", HttpStatus.OK);

}

	@RequestMapping(value = "/addPostpaidAccount/{customerId}/{planId}", method = RequestMethod.POST)
	public ResponseEntity<String> addPostpaidAccount(@PathVariable("customerId") int customerID, @PathVariable("planId") int planId)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		long mobileNo = service.openPostpaidMobileAccount(customerID,planId);
		return new ResponseEntity<>("Postpaid Account Created. Mobile No. "+ mobileNo, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getPostpaidAccountDetails/{customerID}/{mobileNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PostpaidAccount> getPostpaidAccountDetails(@PathVariable("customerID") int customerID,
			@PathVariable("mobileNo") long mobileNo)throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, BillingServicesDownException {
		if (customerID != 0) {
			if (mobileNo != 0L) {
				PostpaidAccount ppa = service.getPostPaidAccountDetails(
						customerID, mobileNo);
				if (ppa != null)
					return new ResponseEntity<>(ppa, HttpStatus.OK);
				else
					throw new BillingServicesDownException(
							"No Such Account Exists");
			} else
				throw new PostpaidAccountNotFoundException(
						"Enter Mobile Number");
		} else
			throw new CustomerDetailsNotFoundException("Enter Customer Id");
	}
	
	@RequestMapping(value = "/getCustomersAllPostpaidAccountsJSON/{customerID}", headers = "Accept=application/json", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList<PostpaidAccount>> getCustomersAllPostpaidAccounts(@PathVariable("customerID") int customerID)
			throws CustomerDetailsNotFoundException,BillingServicesDownException {
		ArrayList<PostpaidAccount> postpaidAccounts = (ArrayList<PostpaidAccount>) service.getCustomerAllPostpaidAccountsDetails(customerID);
		return new ResponseEntity<>(postpaidAccounts, HttpStatus.OK);
	}
	
	@RequestMapping(value="/deletePostpaidAccount/{customerID}/{mobileNo}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deletePostpaidAccount(@PathVariable("customerID") int customerID,
			@PathVariable("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException
	{
		
		service.closeCustomerPostPaidAccount(customerID, mobileNo);
		return new ResponseEntity<>("Postpaid Account Deleted Successfully", HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/addNewPlan", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> addPlan(@ModelAttribute Plan plan)throws BillingServicesDownException {
		return new ResponseEntity<>("New Plan Added. planID - " + service.acceptPlanDetails(plan),	HttpStatus.OK);
	}
	
	@RequestMapping(value="/getPlanDetails/{planId}",method=RequestMethod.GET,headers="Accept=application/json")
	public ResponseEntity<Plan> getPlanDetails(@PathVariable ("planId") int planId) throws PlanDetailsNotFoundException, BillingServicesDownException
	{
		
		return new ResponseEntity<>(service.getPlanDetails(planId),HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/getAllPlansJson",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList<Plan>> getAllPlanDetails() throws BillingServicesDownException
	{
		return new ResponseEntity<>((ArrayList<Plan>)service.getPlanAllDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/deletePlan/{planId}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deletePlan(@PathVariable ("planId") int planId) throws PlanDetailsNotFoundException, BillingServicesDownException
	{
		service.removePlan(planId);
		return new ResponseEntity<>("Plan Successfully Deleted ",HttpStatus.OK);
	}
	
	@RequestMapping(value="/changePlan",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> changePlan(@ModelAttribute PostpaidAccount ppa,@RequestParam ("planId") int planId ) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException{
		service.changePlan(ppa.getCustomer().getCustomerID(), ppa.getMobileNo(), planId);
		return new ResponseEntity<>("Plan Successfully Updated",HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/getCustomerPostpaidAccountPlanDetails/{customerID}/{mobileNo}",method=RequestMethod.GET,produces=MediaType.APPLICATION_XHTML_XML_VALUE)
	public ResponseEntity<Plan> getCustomerPostpaidAccountPlanDetails(@PathVariable ("customerID") int customerID,@PathVariable ("mobileNo") long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException
	{
		Plan plan = service.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
		return new ResponseEntity<>(plan,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/getMobileBillDetails/{customerID}/{mobileNo}/{billMonth}",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Bill> getMobileBillDetails(@PathVariable ("customerID") int customerID,@PathVariable ("mobileNo") long mobileNo,@PathVariable ("billMonth") String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException
	{
		return new ResponseEntity<>(service.getMobileBillDetails(customerID, mobileNo, billMonth),HttpStatus.OK);
	}
	
	@RequestMapping(value="/getCustomerPostpaidAccountAllBills",produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ArrayList<Bill>> getCustomerPostpaidAccountAllBills(@ModelAttribute PostpaidAccount ppa) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException
	{	
		return new ResponseEntity<>((ArrayList<Bill>)service.getCustomerPostPaidAccountAllBillDetails(ppa.getCustomer().getCustomerID(), ppa.getMobileNo()),HttpStatus.OK);
	}
		
}


