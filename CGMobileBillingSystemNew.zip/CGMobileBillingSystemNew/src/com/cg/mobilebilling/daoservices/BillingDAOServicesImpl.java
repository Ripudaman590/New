package com.cg.mobilebilling.daoservices;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
@Repository("billdao")
public class BillingDAOServicesImpl implements BillingDAOServices {
	@PersistenceContext
	EntityManager em;
	
	@Override
	public int insertCustomer(Customer customer)throws BillingServicesDownException {
		try {
			em.persist(customer);
		} catch (Exception e) {
		}
		return customer.getCustomerID();
	}

	@Override
	public long insertPostPaidAccount(int customerID, PostpaidAccount account) {
		Customer cust = em.find(Customer.class,customerID);
		account.setMobileNo((long) (Math.random()*10000000000L));
		account.setCustomer(cust);
		em.persist(account);
		cust.setPostpaidAccounts(account);
		em.flush();
		System.out.println("account inserted "+account);
		/*Customer customer = em.find(Customer.class, customerID);
		customer.setPostpaidAccounts(account);
		em.merge(customer);
		System.out.println("Customer--"+customer);*/
		return account.getMobileNo();
	}

	@Override
	public boolean updatePostPaidAccount(int customerID, PostpaidAccount account) {
		em.merge(account);
		return true;
	}

	@Override
	public double insertMonthlybill(int customerID, long mobileNo, Bill bill) {
		em.merge(bill);
		return bill.getTotalBillAmount();
	}

	@Override
	public int insertPlan(Plan plan){
		em.persist(plan);
		return plan.getPlanID();
	}

	@Override
	public boolean deletePostPaidAccount(int customerID, long mobileNo) {
		
		PostpaidAccount ppa = em.find(PostpaidAccount.class, mobileNo);
		em.remove(ppa);
		return true;
	}

	@Override
	public Bill getMonthlyBill(int customerID, long mobileNo, String billMonth) {
		PostpaidAccount ppa = em.find(PostpaidAccount.class, mobileNo);
		TypedQuery<Bill> query = em.createQuery("SELECT Bill b FROM Bill where b.mobileNo =:mn AND b.billMonth =: bm", Bill.class);
		query.setParameter("mn",mobileNo);
		query.setParameter("bm", billMonth);
		Bill bill = (Bill) query.getSingleResult();
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBills(int customerID,long mobileNo) {
		TypedQuery<Bill> query = em.createQuery("FROM Bill b where b.mobileNo =:mn ", Bill.class);
		query.setParameter("mn",mobileNo);
		List<Bill> bills = query.getResultList();
		return bills;
	}

	@Override
	public List<PostpaidAccount> getCustomerPostPaidAccounts(int customerID) {
		TypedQuery<PostpaidAccount> query = em.createQuery("FROM PostpaidAccount p WHERE p.customerID =: cid", PostpaidAccount.class);
		query.setParameter("cid",customerID);
		List<PostpaidAccount> postpaidAccounts = query.getResultList();
		return postpaidAccounts;
	}

	@Override
	public Customer getCustomer(int customerID) {
		System.out.println("Customer ID is  "+customerID);
		Customer cust = em.find(Customer.class,customerID);
		return cust;
	}

	@Override
	public List<Customer> getAllCustomers() {
		TypedQuery<Customer> query = em.createQuery("FROM Customer ",Customer.class);
		List<Customer> customers = query.getResultList();
		System.out.println("In Dao "+customers);
		return customers;
	}

	@Override
	public List<Plan> getAllPlans() {
		TypedQuery<Plan> planList = em.createQuery("FROM Plan",Plan.class);
		return planList.getResultList();
	}

	@Override
	public Plan getPlan(int planID) {
		return em.find(Plan.class,planID);
	}

	@Override
	public PostpaidAccount getCustomerPostPaidAccount(int customerID,long mobileNo) {
		PostpaidAccount ppa = em.find(PostpaidAccount.class,mobileNo);
		System.out.println("account found"+ppa);
		return ppa;
	}

	@Override
	public Plan getPlanDetails(int customerID, long mobileNo) {
		return em.find(PostpaidAccount.class, mobileNo).getPlan();
	}

	@Override
	public boolean deleteCustomer(int customerID) {
		em.remove(em.find(Customer.class,customerID));
		return true;
	}

	@Override
	public boolean removePlan(int planId) {
		// TODO Auto-generated method stub
		return false;
	}

}