package com.cg.mobilebilling.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.BillingDAOServicesImpl;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

@Service("service")
@Transactional
public class BillingServicesImpl implements BillingServices {
	@Autowired
	BillingDAOServices billdao;
	
	public BillingServicesImpl(BillingDAOServices dao) {
		billdao = dao;
	}

	public BillingServicesImpl() {
		billdao = new BillingDAOServicesImpl();
	}

	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		
		ArrayList<Plan> plans = (ArrayList<Plan>) billdao.getAllPlans();
		if(plans!=null)
		return plans;
		else
			throw new BillingServicesDownException("No Plans Available");
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		if(billdao.getCustomer(customerID)!=null)
		{
			if(billdao.getPlan(planID)!=null)
			{
				PostpaidAccount ppa = new PostpaidAccount();
				//ppa.setCustomer(billdao.getCustomer(customerID));
				System.out.println("2");
				ppa.setPlan(billdao.getPlan(planID));
				long mobileNo = billdao.insertPostPaidAccount(customerID, ppa);
				if(mobileNo!=0L)
					return mobileNo;
				else
					throw new BillingServicesDownException("Server down");
			}else
				throw new PlanDetailsNotFoundException("No such Plan exist");
		}
		else
			throw new CustomerDetailsNotFoundException("No such customer exist");
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = billdao.getCustomer(customerID);
		if(customer != null)
			return customer;
		else 
			throw new CustomerDetailsNotFoundException("Customer with id "+customerID+" is not present");
		
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		
		ArrayList<Customer> customers = (ArrayList<Customer>) billdao.getAllCustomers();
		if(customers!= null)
			return customers;
		else
			throw new BillingServicesDownException("Customer yet to be added");
		
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		if(billdao.getCustomer(customerID)!=null)
		{
			PostpaidAccount ppa = billdao.getCustomerPostPaidAccount(customerID, mobileNo);
			if(ppa!=null)
				return ppa;
			else
				throw new PostpaidAccountNotFoundException("No Such PostpaidAccount Exist");
		}
		else
			throw new CustomerDetailsNotFoundException("No Such Customer Exist");
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		
		if(billdao.getCustomer(customerID)!=null)
		{
		ArrayList<PostpaidAccount> postpaidAccounts = (ArrayList<PostpaidAccount>)billdao.getCustomerPostPaidAccounts(customerID);
		if(postpaidAccounts!=null)
			return postpaidAccounts;
		else
			throw new BillingServicesDownException("No Accounts found related to the current Customer");
		}
		else
			throw new CustomerDetailsNotFoundException("No Such Customer Exist");
		
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		if(billdao.getCustomer(customerID)!=null)
		{
			if(billdao.getCustomerPostPaidAccount(customerID, mobileNo)!=null)
			{
				ArrayList<Bill> bills = (ArrayList<Bill>) billdao.getCustomerPostPaidAccountAllBills(customerID, mobileNo);
				if(bills!=null)
				return bills;
				else
					throw new BillingServicesDownException("No Bills yet");
			}else
				throw new PostpaidAccountNotFoundException("postpaid Account does not exist");
			
		}else
			throw new CustomerDetailsNotFoundException("Customer does not exist");
		
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		if(billdao.getCustomer(customerID)!= null ){
			if(billdao.getCustomerPostPaidAccount(customerID, mobileNo)!= null ){
				if(billdao.getPlan(planID)!=null){
					PostpaidAccount account = new PostpaidAccount();
					account.setCustomer(billdao.getCustomer(customerID));
					account.setMobileNo(mobileNo);
					account.setPlan(billdao.getPlan(planID));
					if(billdao.updatePostPaidAccount(customerID, account))
						return true;
					else
						throw new BillingServicesDownException("Server Down");
				}else
					throw new PlanDetailsNotFoundException("no such plan");
			}else
				throw new PostpaidAccountNotFoundException("No such Account");
		}else
			throw new CustomerDetailsNotFoundException("No Such Customer exist");
	
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		if(billdao.getCustomer(customerID)!=null){
			if(billdao.getCustomerPostPaidAccount(customerID, mobileNo)!= null){
				if(billdao.deletePostPaidAccount(customerID, mobileNo))
					return true;
				else
					throw new BillingServicesDownException("Server Down");
			}else throw new PostpaidAccountNotFoundException("no such account");
		}
		else throw new CustomerDetailsNotFoundException("no such customer");
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		if(billdao.getCustomer(customerID)!= null){
			if(billdao.deleteCustomer(customerID))
				return true;
			else
				throw new BillingServicesDownException("Server Down");
		}else
			throw new CustomerDetailsNotFoundException("no such customer");
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		if(billdao.getCustomer(customerID)!=null){
			if(billdao.getCustomerPostPaidAccount(customerID, mobileNo)!=null){
				Plan plan = billdao.getPlanDetails(customerID, mobileNo);
				if(plan!=null)
					return plan;
				else
					throw new BillingServicesDownException("No Plan");
			}else
				throw new PostpaidAccountNotFoundException("no such account");
		}else
			throw new CustomerDetailsNotFoundException("no such customer");
	}

	@Override
	public int acceptCustomerDetails(Customer customer) throws BillingServicesDownException {
		if(customer != null){
			int custId = billdao.insertCustomer(customer);
			if(custId != 0)
				return custId;
			else throw new BillingServicesDownException("Server Down");
		}else
			throw new BillingServicesDownException("No input found");
	}

	@Override
	public boolean authenticateCustomer(Customer customer)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Plan getPlanDetails(int planId) throws PlanDetailsNotFoundException,
			BillingServicesDownException {
		Plan plan = billdao.getPlan(planId);
		if(plan != null)
			return plan;
		else throw new PlanDetailsNotFoundException("No such plan");
	}

	
	@Override
	public int acceptPlanDetails(Plan plan) throws BillingServicesDownException {
		if(plan != null){
			int planId = billdao.insertPlan(plan);
			if(planId != 0)
				return planId;
			else throw new BillingServicesDownException("Server Down");
		}else
			throw new BillingServicesDownException("No input found");
	}

	@Override
	public boolean removePlan(int planId) throws PlanDetailsNotFoundException,
			BillingServicesDownException {
		if(billdao.getPlan(planId)!= null){
			if(billdao.removePlan(planId))
				return true;
			else
				throw new BillingServicesDownException("server down");
		}else
			throw new PlanDetailsNotFoundException("No such plan");
	}
	
	

}
